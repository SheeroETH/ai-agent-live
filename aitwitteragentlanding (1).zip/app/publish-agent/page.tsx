import PublishAgentPage from "@/components/publish-agent-page"

export default function PublishAgent() {
  return <PublishAgentPage />
}
