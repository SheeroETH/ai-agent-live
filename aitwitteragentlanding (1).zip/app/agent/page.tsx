import AgentDashboard from "@/components/agent-dashboard"

export default function AgentPage() {
  return <AgentDashboard />
}
